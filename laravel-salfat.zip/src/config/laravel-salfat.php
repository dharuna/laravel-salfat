<?php

return [
    'base_url' => env('SALFAT_BASE_URL'),
    'auth_token' => env('SALFAT_API_KEY'),
];
